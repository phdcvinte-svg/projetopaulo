# Portfólio — Projeto Audiovisual (Pacote Mensal)

Site estático (HTML + CSS + JS em um único arquivo). Não precisa de build.

## Como publicar
1. Crie um repositório no GitHub e envie estes arquivos (index.html na raiz).
2. Na Vercel: Add New > Project > importe o repositório.
3. Framework Preset: **Other**. Deixe Build Command e Output Directory em branco. Clique em Deploy.
